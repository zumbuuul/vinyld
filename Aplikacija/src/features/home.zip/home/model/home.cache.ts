import { unstable_cache } from "next/cache";

import { queryFeaturedAlbums, queryRecentActivity } from "./home.queries";

export const getCachedFeaturedAlbums = unstable_cache(
  async () => queryFeaturedAlbums(),
  ["home", "featured-albums"],
  { revalidate: 60 },
);

export const getCachedRecentActivity = unstable_cache(
  async () => queryRecentActivity(),
  ["home", "recent-activity"],
  { revalidate: 30 },
);
